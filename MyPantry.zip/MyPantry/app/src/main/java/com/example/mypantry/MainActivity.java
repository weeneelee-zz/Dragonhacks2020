package com.example.mypantry;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.getbase.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabItem;
import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {


    RecyclerView myrecyclerView;
    RecyclerViewAdapter myAdapter;

    List<Recipes> recipes1;

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private TabItem tab1, tab2, tab3, tab4;

    public PagerAdapter pagerAdapter;

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.aryList).setVisibility(View.INVISIBLE);
        findViewById(R.id.recipeList).setVisibility(View.INVISIBLE);
        findViewById(R.id.recyclerView_id).setVisibility(View.INVISIBLE);


        ////RECIPES////
        recipes1 = new ArrayList<>();

        recipes1.add(new Recipes("Banana Soft Serve Dairy-Free Ice Cream Recipe","Banana","Method",
                "Recipe loads here\n",R.drawable.bananaice));

        recipes1.add(new Recipes("One-Ingredient Banana Ice Cream","Milk" +
                "Banana","Method",
                "Cook it up!",R.drawable.banana_soft));

        recipes1.add(new Recipes("Miso Maple Glazed Salmon","3 cups rice" +
                "Salmon", "Method","You do it",R.drawable.salmon));

        recipes1.add(new Recipes("OREO AND FUDGE ICE CREAM CAKE","1 1/4 cups milk" +
                "1 egg","Method",
                " Put it together and freeze it.",R.drawable.icecream));

        recipes1.add(new Recipes("Turkey Stuffed Zucchini Boats","Zuchinni","Method",
                "Fry it.",R.drawable.zucchini));



        myrecyclerView = findViewById(R.id.recyclerView_id);

        myAdapter = new RecyclerViewAdapter(this,recipes1);

        myrecyclerView.setLayoutManager(new GridLayoutManager(this,1));

        myrecyclerView.setAdapter(myAdapter);


        ///ARRAY LIST///
        listView = findViewById(R.id.aryList);
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("ZUCHINNI");
        arrayList.add("BANANA");
        arrayList.add("POTATOES");
        arrayList.add("BROCCOLI");
        arrayList.add("SPOUTS");
        arrayList.add("GRAPES");
        arrayList.add("PEAS");
        arrayList.add("TONATOES");
        arrayList.add("LETTUCE");

        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, arrayList);
        listView.setAdapter(arrayAdapter);








        ///TABS AND MENU///
        tabLayout = (TabLayout) findViewById(R.id.tablayout);
        tab1 = (TabItem) findViewById(R.id.tab1);
        tab2 = (TabItem) findViewById(R.id.tab2);
        tab3 = (TabItem) findViewById(R.id.tab3);
        tab4 = (TabItem) findViewById(R.id.tab4);

        viewPager = findViewById(R.id.viewpager);

        pagerAdapter = new PageAdapter(getSupportFragmentManager(),tabLayout.getTabCount());

        viewPager.setAdapter(pagerAdapter);

        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                viewPager.setCurrentItem(tab.getPosition());

                if (tab.getPosition() == 0){
                    pagerAdapter.notifyDataSetChanged();
                    findViewById(R.id.menu_option).setVisibility(View.VISIBLE);
                    findViewById(R.id.aryList).setVisibility(View.INVISIBLE);
                    findViewById(R.id.recyclerView_id).setVisibility(View.INVISIBLE);
                }
                else if (tab.getPosition() == 1){
                    pagerAdapter.notifyDataSetChanged();
                    findViewById(R.id.menu_option).setVisibility(View.INVISIBLE);
                    findViewById(R.id.aryList).setVisibility(View.INVISIBLE);
                    findViewById(R.id.recyclerView_id).setVisibility(View.INVISIBLE);
                }
                else if (tab.getPosition() == 2){
                    pagerAdapter.notifyDataSetChanged();
                    findViewById(R.id.menu_option).setVisibility(View.INVISIBLE);
                    findViewById(R.id.aryList).setVisibility(View.VISIBLE);
                    findViewById(R.id.recyclerView_id).setVisibility(View.INVISIBLE);
                }
                else if (tab.getPosition() == 3){
                    pagerAdapter.notifyDataSetChanged();
                    findViewById(R.id.menu_option).setVisibility(View.INVISIBLE);
                    findViewById(R.id.aryList).setVisibility(View.INVISIBLE);
                    findViewById(R.id.recyclerView_id).setVisibility(View.VISIBLE);
                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });


        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));



        FloatingActionButton action1 = findViewById(R.id.action1);

        action1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToast("This is launches the camera!");

            }
        });

        FloatingActionButton action2 = findViewById(R.id.action2);

        action2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToast("This is where you donate items!");

            }
        });

        FloatingActionButton action3 = findViewById(R.id.action3);

        action3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showToast("This is where you add items!");

            }
        });



    }

    public void showToast(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }

    ///ANIMATION///

    public void openTab2(View view) {
        Intent intent = new Intent(this, tab2.class);
        startActivity(intent);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

    }
}
